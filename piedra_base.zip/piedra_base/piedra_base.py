import pygame
import random

# Inicializamos Pygame
pygame.init()

# Tamaño de la ventana
WIDTH, HEIGHT = 600, 400
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Piedra-Papel-Tijera")

# Colores
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (200, 200, 200)

# Fuente para escribir texto
font = pygame.font.Font(None, 24)

# Cargar imágenes
rock_img = pygame.image.load("images/piedra.png")
paper_img = pygame.image.load("images/papel.png")
scissors_img = pygame.image.load("images/tijera.png")

# Escalar imágenes
rock_img = pygame.transform.scale(rock_img, (100, 100))
paper_img = pygame.transform.scale(paper_img, (100, 100))
scissors_img = pygame.transform.scale(scissors_img, (100, 100))

# Definir botones (rectángulos) en las posiciones de las imágenes
rock_rect = pygame.Rect(50, 250, 100, 100)
paper_rect = pygame.Rect(250, 250, 100, 100)
scissors_rect = pygame.Rect(450, 250, 100, 100)

# Botón de reinicio
reset_rect = pygame.Rect(WIDTH // 2 - 50, HEIGHT - 50, 100, 30)

# Opciones posibles
opciones = ["piedra", "papel", "tijera"]
imagenes = {"piedra": rock_img, "papel": paper_img, "tijera": scissors_img}

# Función para decidir el ganador
def determinar_ganador(jugador, computadora):
    if jugador == computadora:
        return "¡Es un empate!"
    elif (jugador == "piedra" and computadora == "tijera") or \
         (jugador == "tijera" and computadora == "papel") or \
         (jugador == "papel" and computadora == "piedra"):
        return "¡Tú ganas!"
    else:
        return "¡El computador gana!"

# Variables para mostrar resultados
eleccion_jugador = ""
eleccion_computador = ""
resultado = ""

# Bucle principal
running = True
while running:
    screen.fill(WHITE)

    # Dibujar botón de reinicio
    pygame.draw.rect(screen, GRAY, reset_rect, border_radius=5)
    texto_reset = font.render("Reiniciar", True, BLACK)
    text_x = reset_rect.x + (reset_rect.width - texto_reset.get_width()) // 2
    text_y = reset_rect.y + (reset_rect.height - texto_reset.get_height()) // 2
    screen.blit(texto_reset, (text_x, text_y))

    # Dibujamos las imágenes
    screen.blit(rock_img, rock_rect.topleft)
    screen.blit(paper_img, paper_rect.topleft)
    screen.blit(scissors_img, scissors_rect.topleft)

    # Mostrar imágenes elegidas y resultado si hubo jugada
    if eleccion_jugador:
        # Imagen del jugador
        screen.blit(font.render("Tú elegiste:", True, BLACK), (50, 30))
        screen.blit(imagenes[eleccion_jugador], (180, 20))

        # Imagen del computador
        screen.blit(font.render("Computador eligió:", True, BLACK), (300, 30))
        screen.blit(imagenes[eleccion_computador], (480, 20))

        # Resultado del juego
        resultado_text = font.render(resultado, True, BLACK)
        screen.blit(resultado_text, (WIDTH // 2 - resultado_text.get_width() // 2, 150))

    # Comprobamos eventos
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.MOUSEBUTTONDOWN:
            # Verificamos si se ha hecho clic sobre alguna opción válida
            clic_en_opcion = False
            
            if rock_rect.collidepoint(event.pos):
                eleccion_jugador = "piedra"
                clic_en_opcion = True
            elif paper_rect.collidepoint(event.pos):
                eleccion_jugador = "papel"
                clic_en_opcion = True
            elif scissors_rect.collidepoint(event.pos):
                eleccion_jugador = "tijera"
                clic_en_opcion = True
            elif reset_rect.collidepoint(event.pos):
                eleccion_jugador = ""
                eleccion_computador = ""
                resultado = ""
            
            # Solo si se ha hecho clic en una opción, la máquina juega
            if clic_en_opcion:
                eleccion_computador = random.choice(opciones)
                resultado = determinar_ganador(eleccion_jugador, eleccion_computador)

    pygame.display.flip()

pygame.quit()